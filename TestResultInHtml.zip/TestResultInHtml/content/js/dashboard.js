/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.7645211930926217, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.925, 500, 1500, "01_04_ClickOnFish"], "isController": false}, {"data": [0.8, 500, 1500, "01_01_ClickEnterJPetStoreDemo"], "isController": false}, {"data": [0.475, 500, 1500, "01_09_ClickOnConfirm"], "isController": false}, {"data": [0.4358974358974359, 500, 1500, "01_10_ClickOnSignOut"], "isController": false}, {"data": [1.0, 500, 1500, "01_05_ClickOnProduct"], "isController": false}, {"data": [0.9736842105263158, 500, 1500, "01_10_ClickOnSignOut-1"], "isController": false}, {"data": [1.0, 500, 1500, "01_01_ClickEnterJPetStoreDemo-1"], "isController": false}, {"data": [0.4, 500, 1500, "01_03_EnterCredsAndClickLogin"], "isController": false}, {"data": [1.0, 500, 1500, "01_01_ClickEnterJPetStoreDemo-0"], "isController": false}, {"data": [0.5789473684210527, 500, 1500, "01_10_ClickOnSignOut-0"], "isController": false}, {"data": [0.925, 500, 1500, "01_06_ClickOnAddToCart-1"], "isController": false}, {"data": [0.95, 500, 1500, "01_09_ClickOnConfirm-0"], "isController": false}, {"data": [0.8, 500, 1500, "01_02_ClickOnSignIn"], "isController": false}, {"data": [0.975, 500, 1500, "01_09_ClickOnConfirm-1"], "isController": false}, {"data": [0.4, 500, 1500, "01_06_ClickOnAddToCart"], "isController": false}, {"data": [0.675, 500, 1500, "01_06_ClickOnAddToCart-0"], "isController": false}, {"data": [0.925, 500, 1500, "01_07_ClickOnProceedToCheckOut"], "isController": false}, {"data": [0.6, 500, 1500, "01_03_EnterCredsAndClickLogin-0"], "isController": false}, {"data": [1.0, 500, 1500, "01_03_EnterCredsAndClickLogin-1"], "isController": false}, {"data": [0.925, 500, 1500, "01_08_EnterPaymentDetailsAndContinue"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 437, 0, 0.0, 597.9839816933633, 77, 5205, 360.0, 1261.0, 1396.7999999999993, 3298.2400000000034, 0.4587290790147717, 2.973440663931613, 0.34565932365540947], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["01_04_ClickOnFish", 40, 0, 0.0, 457.3, 312, 1302, 338.5, 931.3, 1283.7499999999984, 1302.0, 0.052683291757435594, 0.2851277372262774, 0.030707053403735772], "isController": false}, {"data": ["01_01_ClickEnterJPetStoreDemo", 60, 0, 0.0, 542.8666666666669, 280, 1331, 411.5, 962.5, 1265.55, 1331.0, 0.07894508316864512, 1.203262352109544, 0.0698941527350524], "isController": false}, {"data": ["01_09_ClickOnConfirm", 40, 0, 0.0, 822.0, 652, 2525, 711.5, 994.2999999999998, 2449.049999999994, 2525.0, 0.05284706982815454, 0.33192759439477554, 0.07574574647146722], "isController": false}, {"data": ["01_10_ClickOnSignOut", 39, 0, 0.0, 1307.5897435897436, 0, 3565, 1261.0, 1816.0, 3565.0, 3565.0, 0.05215256363281386, 0.3087025369882028, 0.06271209962878073], "isController": false}, {"data": ["01_05_ClickOnProduct", 40, 0, 0.0, 370.49999999999994, 289, 473, 371.0, 456.09999999999997, 472.29999999999995, 473.0, 0.052944228549645804, 0.2902108934073847, 0.03173810028828133], "isController": false}, {"data": ["01_10_ClickOnSignOut-1", 19, 0, 0.0, 387.1578947368422, 287, 1215, 323.0, 462.0, 1215.0, 1215.0, 0.026050592993761567, 0.14828860886405704, 0.015846462175224514], "isController": false}, {"data": ["01_01_ClickEnterJPetStoreDemo-1", 20, 0, 0.0, 93.39999999999999, 77, 121, 90.0, 111.80000000000001, 120.55, 121.0, 0.02701957838649886, 0.45170455121155795, 0.010739226956352575], "isController": false}, {"data": ["01_03_EnterCredsAndClickLogin", 40, 0, 0.0, 1215.85, 576, 1823, 1267.0, 1725.7, 1818.1499999999996, 1823.0, 0.050542127495043714, 0.304585418722573, 0.0718991378144826], "isController": false}, {"data": ["01_01_ClickEnterJPetStoreDemo-0", 20, 0, 0.0, 228.35, 199, 299, 223.0, 265.20000000000005, 297.34999999999997, 299.0, 0.027011477176652362, 0.014006928106252346, 0.010287574315326582], "isController": false}, {"data": ["01_10_ClickOnSignOut-0", 19, 0, 0.0, 954.4736842105261, 291, 2349, 947.0, 1395.0, 2349.0, 2349.0, 0.026013179097999863, 0.009954159045261562, 0.016279629353271294], "isController": false}, {"data": ["01_06_ClickOnAddToCart-1", 20, 0, 0.0, 456.2, 285, 1728, 322.0, 1249.300000000002, 1708.4999999999998, 1728.0, 0.027025420110155615, 0.15856320705255364, 0.016147952435936242], "isController": false}, {"data": ["01_09_ClickOnConfirm-0", 20, 0, 0.0, 426.5, 309, 2025, 336.5, 422.8000000000001, 1945.199999999999, 2025.0, 0.027013775674905417, 0.007808669531027347, 0.01946495545090719], "isController": false}, {"data": ["01_02_ClickOnSignIn", 60, 0, 0.0, 451.8666666666666, 211, 1487, 326.5, 866.6, 1225.0999999999995, 1487.0, 0.0770802019501291, 1.5731687831605452, 0.05669861078994361], "isController": false}, {"data": ["01_09_ClickOnConfirm-1", 20, 0, 0.0, 395.15, 342, 672, 374.5, 496.0000000000001, 663.3999999999999, 672.0, 0.027001375720092938, 0.16178807708690257, 0.01924507233331038], "isController": false}, {"data": ["01_06_ClickOnAddToCart", 40, 0, 0.0, 1308.7, 570, 4200, 1256.0, 2493.1999999999985, 4119.549999999993, 4200.0, 0.05211746756013379, 0.3192703847702337, 0.06319751901310364], "isController": false}, {"data": ["01_06_ClickOnAddToCart-0", 20, 0, 0.0, 852.1999999999999, 285, 2863, 912.0, 1172.8, 2778.549999999999, 2863.0, 0.027000719569176518, 0.006987490904132595, 0.016607815645161943], "isController": false}, {"data": ["01_07_ClickOnProceedToCheckOut", 40, 0, 0.0, 563.55, 289, 4261, 329.0, 817.9999999999994, 4090.7499999999854, 4261.0, 0.05289242210268535, 0.31182768772842917, 0.03165539148987375], "isController": false}, {"data": ["01_03_EnterCredsAndClickLogin-0", 20, 0, 0.0, 867.0500000000001, 286, 1413, 946.5, 1297.7, 1407.25, 1413.0, 0.026998787754429827, 0.006644232923941715, 0.02021876991160597], "isController": false}, {"data": ["01_03_EnterCredsAndClickLogin-1", 20, 0, 0.0, 348.4, 289, 428, 320.0, 427.8, 428.0, 428.0, 0.027025602704722318, 0.15621537344653458, 0.01820665236899677], "isController": false}, {"data": ["01_08_EnterPaymentDetailsAndContinue", 40, 0, 0.0, 619.2500000000002, 291, 5205, 328.5, 938.8999999999993, 4994.249999999982, 5205.0, 0.05267531331934804, 0.3012266598978889, 0.05225607132369112], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 437, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
